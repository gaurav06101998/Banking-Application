package com.bankingapi.bankingproject.repository;
import java.util.Optional;
import org.springframework.stereotype.Repository;

import com.bankingapi.bankingproject.model.ERole;
import com.bankingapi.bankingproject.model.Role;

import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface RoleRepository  extends JpaRepository<Role, Long> {
    Optional<Role> findByName(ERole name);

}