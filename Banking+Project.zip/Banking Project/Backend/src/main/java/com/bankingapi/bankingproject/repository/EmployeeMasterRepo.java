package com.bankingapi.bankingproject.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.bankingapi.bankingproject.model.EmployeeMaster;

public interface EmployeeMasterRepo extends JpaRepository<EmployeeMaster, Integer>   {

  
    
}
