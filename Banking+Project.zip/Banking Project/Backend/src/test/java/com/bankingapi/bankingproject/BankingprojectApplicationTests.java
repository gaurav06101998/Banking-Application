package com.bankingapi.bankingproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankingProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
